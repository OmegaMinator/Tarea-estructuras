import numpy as np 
#1. En la universidad se efectuó la elección del representante de los estudiantes ante el Consejo Superior.
#  Se presentaron 30 candidatos y cada uno se identificó con un número del 1 al 30. 
# Asumiendo que los 5000 estudiantes de la universidad votaron, 
# elabore un programa donde imprima un listado de mayor a menor, según el número de votos obtenidos por cada candidato

# Generar aleatoriamente la cantidad de votos para cada candidato (entre 0 y 500 votos para simular)
votos = np.random.randint(0, 501, size=30)

# Crear un array con los números de los candidatos (del 1 al 30)
candidatos = np.arange(1, 31)

# Combinar los votos con los números de candidatos
resultado = np.vstack((candidatos, votos)).T

# Ordenar la matriz por el número de votos en orden descendente
resultado_ordenado = resultado[resultado[:, 1].argsort()[::-1]]

# Imprimir listado de resultados
print("Listado de votos por candidato de mayor a menor:")
for candidato, voto in resultado_ordenado:
    print(f"Candidato {int(candidato)}: {int(voto)} votos")
    


