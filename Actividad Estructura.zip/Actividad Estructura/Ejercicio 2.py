#2. Suponga que en la UIS hay 6500 estudiantes. 
# Por cada uno de ellos tenemos un registro con el código, nombre y promedio acumulado. Hacer el programa que:
#Imprima el código y el nombre de los estudiantes de la carrera X (debe leerse el código de la carrera a listar)
# que tengan promedio acumulado igual o mayor a 4 y decir cuántos fueron.
#Imprima el código y el nombre de los estudiantes que ingresaron antes de 1990 y están condicionales
import numpy as np 

# para asegurarnos de que los números aleatorios sean siempre los mismos
np.random.seed(42)

# creamos los códigos de los estudiantes del 1000 al 7499
codigos = np.arange(1000, 1000 + 6500)

# creamos una lista con los nombres de los estudiantes
nombres = np.array(["Estudiante " + str(i) for i in range(6500)])

# Generaramos promedios aleatorios entre 2.0 y 5.0 redondeados a 2 decimales
promedios = np.round(np.random.uniform(2.0, 5.0, 6500), 2)

# Asignamos números de carrera aleatorios entre 1 y 10
carreras = np.random.randint(1, 11, 6500)

# Generaramos años de ingreso aleatorios entre 1980 y 2022
ingresos = np.random.randint(1980, 2023, 6500)

# creamos una lista aleatoria para saber si están condicionales o no (True o False)
condicionales = np.random.choice([True, False], 6500)

# Pedimos al usuario el código de la carrera
codigo_carrera = int(input("Ingrese el código de la carrera a listar: "))

# filtramos a los estudiantes que pertenecen a la carrera y tienen promedio mayor o igual a 4
filtro_carrera = (carreras == codigo_carrera) & (promedios >= 4)
estudiantes_carrera = np.vstack((codigos[filtro_carrera], nombres[filtro_carrera])).T

print(f"\nEstudiantes de la carrera {codigo_carrera} con promedio mayor o igual a 4:")
print(estudiantes_carrera)
print(f"Total: {len(estudiantes_carrera)} estudiantes")

# Filtramos los estudiantes que ingresaron antes de 1990 y están condicionales
filtro_condicional = (ingresos < 1990) & condicionales
estudiantes_condicionales = np.vstack((codigos[filtro_condicional], nombres[filtro_condicional])).T

print("\nEstudiantes que ingresaron antes de 1990 y están condicionales:")
print(estudiantes_condicionales)
print(f"Total: {len(estudiantes_condicionales)} estudiantes")